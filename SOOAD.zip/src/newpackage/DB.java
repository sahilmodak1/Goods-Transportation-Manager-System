import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DB {
    
    private Connection con;
    private Statement st;
    private ResultSet rs;
    
    public DB(){
        try{
            Class.forName("org.sqlite.JDBC");
            con=DriverManager.getConnection("jdbc:sqlite:SOOAD(Project)");
            st=con.createStatement();
            
        }catch(Exception ex){
            System.out.println(ex);
        }
    }
    public void close(){
        if(rs!=null){
            try{
                rs.close();
            }catch(SQLException e){
                
            }
        }
        if(st!=null){
            try{
                st.close();
            }catch(SQLException e){
                
            }
        }        
        if(con!=null){
            try{
                con.close();
            }catch(SQLException e){
                
            }
        }
    }
    public boolean login(String uname,String passwd){
        try{
            String query="select * from LoginInfo";
            rs=st.executeQuery(query);
            while(rs.next()){
                String n=rs.getString("Username");
                String p=rs.getString("Password");
                Globals g=new Globals();
                g.uname=uname;
                if(uname.equals(n)&&passwd.equals(p))
                    return true;
            }
        }
        catch(Exception ex){
            System.out.println(ex);
        }
        return false;
    }
    public void register(String name,String phone,String email,String saddress,String usrname,String pass1,String pass2)
    {
        try
        {
           PreparedStatement st=con.prepareStatement("insert into CustomerDetails values(?,?,?,?,?,?)");
           st.setString(1,saddress);
           st.setString(2,name);
           st.setString(3,phone);
           st.setString(4,email);
           st.setString(5,usrname);
           st.setString(6,pass1);
           st.executeUpdate();
           PreparedStatement a=con.prepareStatement("insert into LoginInfo values(?,?)");
           a.setString(1,usrname);
           a.setString(2,pass1);
           a.executeUpdate();
           Globals g=new Globals();
           g.uname=usrname;
        }
        catch(Exception e){
            System.out.println(e);
        }
    }
    /*public void acceptsrcdest(String src,String dest)
    {
        try
        {   Globals g=new Globals();
            PreparedStatement st=con.prepareStatement("insert into GoodsDetails values(?,?,?,?,?,?,?,?,?,?)");
            st.setString(1,g.uname);
            st.setString(2,src);
            st.setString(3,dest);
            st.executeUpdate();
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }
        public void acceptgoods(int b,int a,int f)
    {
        try{
            Globals g=new Globals();
            g.b=b;
            g.f=f;
            g.a=a;
            g.t=g.a+g.b+g.f;
            PreparedStatement st=con.prepareStatement("update GoodsDetails set Bunker='"+b+"',Automobile='"+a+"',Foodstuff='"+f+"' where Username='"+g.uname+"'");
            st.executeUpdate();
        }
        catch(Exception e){
            System.out.println(e);
        }
    } */
    public boolean isFull(String pickup,int b,int a,int f)
    {
        int tot=0,count=0;
        try{
           Globals g=new Globals();
           g.b=b; g.a=a; g.f=f;
           g.t=g.a+g.b+g.f;
           String q="select COUNT(*) from GoodsDetails";
           rs=st.executeQuery(q);
           while(rs.next())
               count=rs.getInt("COUNT(*)");
           if(count==0 && g.t<=g.capacity)             //checks whether table is empty (first order to be placed)
           {    
               String query="select * from GoodsDetails";
               rs=st.executeQuery(query);
               PreparedStatement st=con.prepareStatement("insert into GoodsDetails values(?,?,?,?,?,?,?,?,?,?,?)");
               st.setString(1,g.daddress);
               st.setString(3,g.uname);
               st.setString(4,g.src);
               st.setString(5,g.dest);
               st.setInt(6,g.b);
               st.setInt(7,g.a);
               st.setInt(8,g.f);
               st.setInt(9,g.t);
               st.setString(11,pickup);
               st.executeUpdate();
               g.pickup=pickup;
               return true;
           } 
           else if(count!=0)       //database has tuples
           {
           String query="select * from GoodsDetails";
           rs=st.executeQuery(query);
           while(rs.next())         //check date entered by user with each and every date in database
            {
            String d=rs.getString("PickUpDate");
            if(pickup.equals(d))                    //if date entered by user equals to a date in database
                tot=tot+rs.getInt("TotalGoods");    //calculate total goods with a same date     
            }
                    if(g.t<=(g.capacity-tot))                 //capacity-total=goods left. That must be larger than the current order placed.
                    {
                          PreparedStatement st=con.prepareStatement("insert into GoodsDetails values(?,?,?,?,?,?,?,?,?,?,?)");
                          st.setString(1,g.daddress);
                          st.setString(3,g.uname);
                          st.setString(4,g.src);
                          st.setString(5,g.dest);
                          st.setInt(6,g.b);
                          st.setInt(7,g.a);
                          st.setInt(8,g.f);
                          st.setInt(9,g.t);
                          st.setString(11,pickup);
                          st.executeUpdate();
                          g.pickup=pickup;
                          return true;
                    }   
          }
         }
       catch(Exception e)
       {
           System.out.println(e);
       }
        return false;
    }
    
    public int calcID()
    {
        try{
                   int n;
                   Globals g=new Globals();
                   String query="select * from GoodsDetails";
                   rs=st.executeQuery(query);
                   while(rs.next())
                   {    
                   String uname=rs.getString("Username");
                   String src=rs.getString("Source");
                   String pickup=rs.getString("PickUpDate");
                   String dest=rs.getString("Destination");
                   int b=rs.getInt("Bunker");
                   int a=rs.getInt("Automobile"); 
                   int f=rs.getInt("Foodstuff");
                  
                   
                  if(uname.equals(g.uname)&&src.equals(g.src)&&dest.equals(g.dest)&&pickup.equals(g.pickup)&&(b==g.b)&&(a==g.a)&&(f==g.f))
                   {
                       int numb=rs.getInt("Number");
                       g.ID=g.deflt+numb;
                       String q="update GoodsDetails set TrackingID="+g.ID+" where Number="+numb+"";
                       st.executeUpdate(q); 
                       return 0;
                   }   
                   }
    }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return 0;
    }
    public boolean Track(int track)
    {
        try{
            String query="select * from GoodsDetails";
            rs=st.executeQuery(query);
            Globals g=new Globals();
            while(rs.next())
            {
                int t=rs.getInt("TrackingID");
                String user=rs.getString("Username");
                if((track==t) && (g.uname.equals(user)))
                {
                    g.a=rs.getInt("Bunker");
                    g.a=rs.getInt("Automobile");
                    g.f=rs.getInt("Foodstuff");
                    g.pickup=rs.getString("PickUpDate");
                    g.ID=track;
                    return true;
                }
                    
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        return false;
    }
    public void cancel()
    {
        try{
              Globals g=new Globals();
              String q="Delete from GoodsDetails where TrackingID="+g.ID+"";
              st.executeUpdate(q);
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    } 
    
    public void deletenull()
    {
        try{
            String q="Delete from GoodsDetails where TrackingID IS NULL";
            st.executeUpdate(q);
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }   
    } 
}  