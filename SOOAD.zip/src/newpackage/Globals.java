public class Globals{
    public static String uname;
    public static int b,f,a,t;
    public static int bunker=100;
    public static int automobile=200;
    public static int foodstuff=150;
    public static int capacity=100;
    public static String src,dest,daddress,pickup;
    public static int deflt=6041200;
    public static int ID;
}